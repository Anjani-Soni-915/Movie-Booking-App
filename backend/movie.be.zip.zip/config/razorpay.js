module.exports = {
  RAZORPAY_KEY_ID: "rzp_test_yZobVDNvJEKGqn",
  RAZORPAY_SECRET_KEY: "OYDGEaDyfD3hvkD5hdTXe3J7",
};
